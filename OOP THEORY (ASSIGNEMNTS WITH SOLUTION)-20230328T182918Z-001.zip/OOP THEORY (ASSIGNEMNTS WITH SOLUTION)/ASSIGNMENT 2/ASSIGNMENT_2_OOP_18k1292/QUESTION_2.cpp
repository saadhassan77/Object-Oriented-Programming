//QUESTION #2       
//Package-delivery services, such as FedEx, DHL and UPS, offer a number of
//different shipping options, each with specific costs associated. Create an
//inheritance hierarchy to represent various types of packages. Use class Package
//as the base class of the hierarchy, then include classes TwoDayPackage and
//OvernightPackage that derive from Package. Base class Package should include
//data members representing the name, address, city, state and ZIP code for both
//the sender and the recipient of the package, in addition to data members that
//store the weight (in ounces) and cost per ounce to ship the package. Package�s
//constructor should initialize these data members. Ensure that the weight and
//cost per ounce contain positive values. Package should provide a public member
//function calculateCost that returns a double indicating the cost associated with
//shipping the package. Package�s calculateCost function should determine the
//cost by multiplying the weight by the cost per ounce. Derived class
//TwoDayPackage should inherit the functionality of base class Package, but also
//include a data member that represents a flat fee that the shipping company
//charges for two-day-delivery service. TwoDayPackage�s constructor should
//receive a value to initialize this data member. TwoDayPackage should redefine
//member function calculateCost so that it computes the shipping cost by adding
//the flat fee to the weight-based cost calculated by base class Package�s
//calculateCost function. Class OvernightPackage should inherit directly from
//class Package and contain an additional data member representing an
//additional fee per ounce charged for overnight-delivery service.
//OvernightPackage should redefine member function calculateCost so that it
//adds the additional fee per ounce to the standard cost per ounce before
//calculating the shipping cost. Write a test program that creates objects of each
//type of Package and tests member function calculateCost.

#include<iostream>
using namespace std;

class package
{
	protected:
	string name_sender;
	string address_sender;
	string city_sender;
	string state_sender;
	int ZipCode_sender;
	
	string name_recipient;
	string address_recipient;
	string city_recipient;
	string state_recipient;
	int ZipCode_recipient;
	
	double weight_per_ounce;
	double cost_per_ounce;
	double cost;
	
    public:
    package(){};    
    package(
	string name_sender,
	string address_sender,
	string city_sender,
	string state_sender,
	int ZipCode_sender,
	string name_recipient,
	string address_recipient,
	string city_recipient,
	string state_recipient,
	int ZipCode_recipient,
	double weight_per_ounce,
	double cost_per_ounce)
	{
	this->name_sender=name_sender; 
	this->address_sender=address_sender;
	this->city_sender=city_sender;
	this->state_sender=state_sender;
	this->ZipCode_sender=ZipCode_sender;
	
	this->name_recipient=name_recipient;
	this->address_recipient=address_recipient;
	this->city_recipient=city_recipient;
	this->state_recipient=state_recipient;
	this->ZipCode_recipient=ZipCode_recipient;
	this->weight_per_ounce=weight_per_ounce;
	this->cost_per_ounce=cost_per_ounce;}    
	      
	double calculateCOst()
	{
		
		cost= weight_per_ounce * cost_per_ounce;
		cout << "PACKAGE COST=" << cost << endl;
	}
};

class TwoDaypackage : public package
{
    int flatfee;
	public:	
	TwoDaypackage(int flatfee,
	string name_sender,
	string address_sender,
	string city_sender,
	string state_sender,
	int ZipCode_sender,
	string name_recipient,
	string address_recipient,
	string city_recipient,
	string state_recipient,
	int ZipCode_recipient,
	double weight_per_ounce,
	double cost_per_ounce){
	this->flatfee=flatfee;	
	this->name_sender=name_sender; 
	this->address_sender=address_sender;
	this->city_sender=city_sender;
	this->state_sender=state_sender;
	this->ZipCode_sender=ZipCode_sender;
	
	this->name_recipient=name_recipient;
	this->address_recipient=address_recipient;
	this->city_recipient=city_recipient;
	this->state_recipient=state_recipient;
	this->ZipCode_recipient=ZipCode_recipient;
	this->weight_per_ounce=weight_per_ounce;
	this->cost_per_ounce=cost_per_ounce;}
	

	double calculateCOst()
	{
		this->cost= weight_per_ounce * cost_per_ounce;
		this->cost = cost + flatfee;
		cout << "COST OF TWO DAYS PACKAGE=" <<  cost << endl;
	}
	print()
	{
		cout << "RECIPIENT NAME=" <<  name_recipient << endl << "SENDER NAME=" << name_sender << endl << "SENDER CITY NAME=" <<city_sender 
        << endl << "RECIPIENT CITY NAME=" <<city_recipient << endl << "SENDERS ZIP CODE=" << ZipCode_sender << endl <<
        "RECIPIENT ZIP CODE=" << ZipCode_recipient << endl << "SENDER STATE=" << state_sender << endl <<
        "RECIPIENT STATE=" << state_recipient << endl  ;
	}
};

class OverNightpackage : public package
{
    int additional_fee_per_ounce;
	public:
		
	OverNightpackage(int additional_fee_per_ounce,
	string name_sender,
	string address_sender,
	string city_sender,
	string state_sender,
	int ZipCode_sender,
	string name_recipient,
	string address_recipient,
	string city_recipient,
	string state_recipient,
	int ZipCode_recipient,
	double weight_per_ounce,
	double cost_per_ounce)
	{
	this->additional_fee_per_ounce =additional_fee_per_ounce;	
	this->name_sender=name_sender; 
	this->address_sender=address_sender;
	this->city_sender=city_sender;
	this->state_sender=state_sender;
	this->ZipCode_sender=ZipCode_sender;
	
	this->name_recipient=name_recipient;
	this->address_recipient=address_recipient;
	this->city_recipient=city_recipient;
	this->state_recipient=state_recipient;
	this->ZipCode_recipient=ZipCode_recipient;
	this->weight_per_ounce=weight_per_ounce;
	this->cost_per_ounce=cost_per_ounce;}	
	double calculateCOst(){
	cost_per_ounce = cost_per_ounce + additional_fee_per_ounce;
	cost= weight_per_ounce * cost_per_ounce;
    cout << "COST OF OVER NIGHT PACKAGE=" << cost;
}
};

int main()
{
    package c("ahmed","nomanAVenue","karachi","sindh",1234,"umair","erumAVenue","lahore","punjab",4321,20,15);
	TwoDaypackage a(20,"ahmed","nomanAVenue","karachi","sindh",1234,"umair","erumAVenue","lahore","punjab",4321,20,15);
	OverNightpackage b(10,"ahmed","nomanAVenue","karachi","sindh",1234,"umair","erumAVenue","lahore","punjab",4321,20,15);
    a.print();
	c.calculateCOst();
    a.calculateCOst();
	b.calculateCOst();
}

