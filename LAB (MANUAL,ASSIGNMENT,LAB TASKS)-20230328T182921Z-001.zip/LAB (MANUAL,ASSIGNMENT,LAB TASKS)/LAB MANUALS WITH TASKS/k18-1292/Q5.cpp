#include<iostream>
#include<iomanip>
using namespace std;
float length,width;
void input()
{
	cout<<"enter length : ";
	cin>>length;
	cout<<"enter width : ";
	cin>>width;	
}
void output()
{
	float area, perimeter;
	area=length*width;
	perimeter=2*(length+width);
	cout<<"area = "<<setprecision(4)<<area<<endl;
	cout<<"perimeter = "<<setprecision(4)<<perimeter;
}
int main()
{
	input();
	output();
}
