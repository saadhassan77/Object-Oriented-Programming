#include <stdio.h> 
#include <iostream> 
using namespace std;  
void draw_solid_line(int size,char symb); 
void draw_hollow_line(int size, char symb); 
void draw_rectangle(int len, int wide, char symb); 
 
int main(void) 
{     
	int length, width;
	char symbol;              
	cout<<"Enter length and width of rectangle > ";
	cin>>length>>width;
	cout<<"enter symbol for frame > ";
	cin>>symbol;          
	draw_rectangle(length, width,symbol);            
	cout<<endl;
	system("pause");     
	return 0; 
} 
void draw_solid_line(int size, char symb) 
{
	cout<<endl;          
	for(int i=0;i<size;i++)
	{
		cout<<symb;
	} 
} 
void draw_hollow_line(int size, char symb) 
{      
	cout<<endl;
	for(int j=0;j<size;j++)
	{   
		if(j==0 || j==size-1)
		{
			cout<<symb;
		}
		else
		{
			cout<<" ";
		}			
	} 
} 
void draw_rectangle(int len, int wide, char symb) 
{      
	int i;      
	draw_solid_line(wide,symb);  
	if (len > 2) 
	{ 
		for (i=1; i<=len - 2; i++)
		{
			draw_hollow_line(wide,symb);
		}         
		      
	}
	draw_solid_line(wide,symb); 
} 
