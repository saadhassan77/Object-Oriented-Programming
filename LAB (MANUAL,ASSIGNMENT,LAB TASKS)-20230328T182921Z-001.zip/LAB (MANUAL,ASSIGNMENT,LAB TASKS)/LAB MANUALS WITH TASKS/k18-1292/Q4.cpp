#include<iostream>
using namespace std;
int is_prime(int n)
{
	bool flag = true;
	cout<<"prime numbers from 2 to 100 are : ";
    for(int i=2;i<100;i++)
	{	
		flag=true;
        for(int j = 2; j <= i/2; ++j)
        {
            if(i % j == 0)
            {
                flag = false;
                break;
            }
        }
        if (flag==true)
        {
        	 cout << i << " ";
		}       
	}
	cout<<endl;
	
	flag= true;
	for(int i=2;i<=n/2;i++)
	{
		if(n%i==0)
		{
			flag = false;
			break;
		}
	}
	return flag;
}
int main()
{
	int n,check;
	cout<<"enter a number : ";
	cin>>n;

	if(is_prime(n))
	{
		cout<<n<<" is prime";
	}
    else	
	{
		cout<<n<<" is not prime";
	}	
}
