#include<iostream>
using namespace std;
bool perfect_Square(int num)
{	
	int n1,n2;
	cout<<"enter your range :"<<endl;
	cout<<"enter n1 :";
	cin>>n1;
	cout<<"enter n2 :";
	cin>>n2;
	cout<<endl<<"perfect squares from range "<<n1 <<" to "<<n2<< " are : ";
	for(int i=n1;i<=n2;i++)
	{
		int square=i*i;
		if(square>n2)
		{
			break;
		}
		else if(square==1)
		{
			continue;
		}
		cout<<square<<" ";
	}
	cout<<endl;
	for(int i=2;i<=num;i++)
	{
		if(num==i*i)
		{
			return true;
		}
	}
	return false;	
}
int main()
{
	int number;
	cout<<"enter positive integer number :";
	cin>>number;
	
	if(perfect_Square(number))
	{
		cout<<endl<<number<<" is perfect square.";
	}	
	else 
	{
		cout<<endl<<number<<" is not perfect square.";
	}
}
