#include<iostream>
using namespace std;
int main()
{
	int i,temp,j;
	
	int *arr,*arr1;
	arr=new int [100];
	arr1=new int [100];
	
	cout<<"Enter 10 numbers in an array : ";
	for(i=1;i<=10;i++)
	{
		cin>>arr[i];
		arr1[i]=arr[i];
	}
	cout<<endl<<"original array : ";
	for(j=1;j<=10;j++)
	{
		cout<<arr[j]<<" ";
	}
	cout<<endl;
	cout<<endl<<"ascending order : ";
	for(i=1;i<=10;i++)
	{
		for(j=1;j<=10-i;j++)
		{
			if(arr1[j]>arr1[j+1])
			{
				temp=arr1[j];
				arr1[j]=arr1[j+1];
				arr1[j+1]=temp;
			}
		}
	}
	for(j=1;j<=10;j++)
	{
		cout<<arr1[j]<<" ";
	}
	cout<<endl;
	cout<<endl<<"descending order : ";
	for(i=1;i<=10;i++)
	{
		for(j=1;j<=10-i;j++)
		{
			if(arr1[j]<arr1[j+1])
			{
				temp=arr1[j];
				arr1[j]=arr1[j+1];
				arr1[j+1]=temp;
			}
		}
	}
	for(j=1;j<=10;j++)
	{
		cout<<arr1[j]<<" ";
	} 
}
