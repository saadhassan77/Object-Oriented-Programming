#include <iostream>
using namespace std;
int j=0;
int *divisors(int number)
{	
	int *z;	
    for(int i=1; i <= number; ++i)
    {
        if (number%i == 0)
        {
			z[j]=i;
			j++;
	    }
    }
    return z;
}
int main()
{
    int number;
    int *z;
    printf("Enter a positive integer > ");
    cin>>number;
    
	z=divisors(number);	
	cout<<"divisors of "<<number<<" are "<<endl;
	for(int i =0;i<j;i++)
    {
    	cout<<z[i]<<" ";
    }
    return 0;
}
