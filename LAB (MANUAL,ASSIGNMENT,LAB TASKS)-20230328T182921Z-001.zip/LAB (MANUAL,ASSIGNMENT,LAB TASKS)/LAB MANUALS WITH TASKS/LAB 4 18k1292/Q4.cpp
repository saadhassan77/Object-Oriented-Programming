#include<iostream>
using namespace std;
class Sales{
	
	private:
		int SaleID,qty;
		string ItemName;
	public:
		Sales(){								 									
			SaleID=244235;
			qty=5;
			ItemName="cornflour";
		}
		Sales(int a){																
			cout<<endl<<"Enter Sale ID : ";
			cin>>SaleID;	
			cout<<"Enter Quantity : ";
			cin>>qty;
			fflush(stdin);
			cout<<"Enter Item Name : ";
			getline(cin,ItemName);
			cout<<endl;
		}
		Sales(int id, int qt, string nam){											 					
			SaleID=id;
			qty=qt;
			ItemName=nam;
		}
		void display(){															 
			cout<<"sales id : "<<SaleID;
			cout<<endl<<"quantity : "<<qty;			
			cout<<endl<<"item name : "<<ItemName;
			cout<<endl;
		}
		void quant(int qty){
			this->qty=qty;
		}
		Sales(const Sales &obj){												
			qty=obj.qty;		
		}
};
int main()
{
	int qt,ID;
	string item;

	Sales s1;
	s1.display();
			
	Sales s2(0);
	s2.display();
	
	cout<<endl;
	cout<<endl<<"Enter Sale ID : ";
	cin>>ID;	
	cout<<"Enter Quantity : ";
	cin>>qt;
	fflush(stdin);
	cout<<"Enter Item Name : ";
	getline(cin,item);
	cout<<endl;
	
	Sales s3(ID,qt,item);	
	s3.display();
	
	cout<<endl;	
	
	Sales s4=s3;
	s4.quant(0);
	s4.display();
}
