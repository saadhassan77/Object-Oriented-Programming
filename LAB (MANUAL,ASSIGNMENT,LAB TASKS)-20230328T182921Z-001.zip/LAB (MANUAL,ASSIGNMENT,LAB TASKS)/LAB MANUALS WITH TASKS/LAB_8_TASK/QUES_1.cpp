/*Design and implement a program that shows the relationship between person, student and
professor. Your person class must contain two pure virtual functions named getData() of type void
and isOutstanding() of type bool and as well getName() and putName() that will read and print the
person name. Class student must consist of function name getData (), which reads the GPA of
specific person and isOutstanding() function which returns true if the person GPA is greater than 3.5
else should return false. Class professor should take the respective persons publications in
getData() and will return true in Outstanding() if publications are greater than 100 else will return
false . Your main function should ask the user either you want to insert the data in professor or
student until and unless user so no to add moredata.*/


#include <iostream>  
  using namespace std;  

  class person{  
     protected:  
        char name[40];  
     public:  
        void getName()  
           { cout << "   Enter name: "; cin >> name; }  
        void putName()  
           { cout << "Name is: " << name << endl; }  
        virtual void getData() = 0;
        virtual bool isOutstanding() = 0;
    };  
  class student : public person{  
     private:  
        float gpa;             
     public:  
        void getData(){  
           person::getName();  
           cout << "   Enter student's GPA: "; cin >> gpa;  
        }  
        bool isOutstanding()  
        { 
           return (gpa > 3.5) ? true : false; 
        }  
  };  
  class professor : public person{  
     private:  
        int numPubs;             
     public:  
        void getData(){  
           person::getName();  
           cout << "   Enter number of professor's publications: ";  
           cin >> numPubs;  
        }  
        bool isOutstanding()  
        { 
           return (numPubs > 100) ? true : false; 
        }  
  };  
  int main(){  
     person* persPtr[100];
     int n = 0;           
     char choice;  
    
     do {  
        cout << "Enter student or professor (s/p): ";  
        cin >> choice;  
        if(choice=='s')   
           persPtr[n] = new student;     
        else                             
           persPtr[n] = new professor;   
        persPtr[n++]->getData();         
        cout << "   Enter another (y/n)? ";
        cin >> choice;  
     } while( choice=='y' );          
    
     for(int j=0; j<n; j++){                                
        persPtr[j]->putName();           
        if( persPtr[j]->isOutstanding() )  
           cout << "   This person is outstanding\n";  
     }  
     return 0;  
  }
