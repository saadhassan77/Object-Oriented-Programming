/*A company pays its employees weekly. The employees are of four types: Salariedemployees are paid
a fixed weekly salary regardless of the number of hours worked, hourlyemployees are paid by the hour
and receive overtime pay for all hours worked in excess of 40 hours, commissionemployees are paid
a percentage of their sales and base-salaryplus-commissionemployees receive a base salary plus a
percentage of their sales. For the current pay period, the company has decided to reward base-salaryplus-commission employees by adding 10 percent to their base salaries. The company wants you to
draw UML diagram of the given scenario and do implementation on c++ that performs its payroll
calculations polymorphically.
Your Employee class must have:
-
First name, last name and social security number as private data members. Use accesor and mutators to set and get
these values.
-
Constructor with first name, last name and ssn number as parameter.
-
Pure virtual function named earning with return type double.
-
Virtual function named print with return type void, which employee first name, last name and ssn number.
Your salaried Employee must have:
-
Earning method which return the salary
-
Print method that print the employee detail and employee salary.
Your hourly Employee must have:
-
You must take the wage and hours as a parameter using base class initializer.
-
Earning methods which returns the salary the employed has worked.
- Print method that print the employee detail and employee salary.
Your commission employee must have:
-
You must take the commission rate and gross sale rate as a parameter using base class initializer.
-
Earning methods which returns the commission of the employee.
-
Print method that print the employee detail and employee commission.
Your base-salary plus-commission employees must have:
-
You must take the base salary as a parameter using base class initializer.
-
Earning methods which return the base commission of the employee.
-
Print method that print the employee detail and employee base salary.
You have to perform upcasting and downcasting, and print the details of each employee type
*/


#include<iostream>
using namespace std;

class Emp{
	protected:
	string first_name,last_name;
	int ssn;
	public:
		void setf(string first)
		{
			first_name=first;
		}
		string getf()
		{
			return first_name;

		}
		void setl(string last)
		{
			last_name=last;
		}
		string getl()
		{
			return last_name;
		}
		Emp(string last,string first,int s)
		{
			last_name=last;
			first_name=first;
			ssn=s;
	}
		virtual double earning()=0;
		virtual void print()
		{
			cout<<"first name is="<<first_name<<endl<<"last name is="<<last_name<<endl<<"ss number="<<ssn<<endl;
		}
};
class  Salaried_Employee:public Emp{
	double salary;
	public:
		 Salaried_Employee(string fn,string ln,int ss,double sal):Emp(fn,ln,ss)
		{
			salary=sal;
		}
	double earning()
	{
	return salary;	
	}
	void print()
	{
		
			cout<<"first name is="<<first_name<<endl<<"last name is="<<last_name<<endl<<"ss number="<<ssn<<endl<<"salary ="<<salary<<endl;
	}
};
class hourly_Employee:public Emp{
	double salary;
	int wage,hours;
	public:
		hourly_Employee(string fn,string ln,int s,int w,int h):Emp(fn,ln,s)
		{
			wage=w;
			hours=h;
		}
		double earning()
		{
		salary=wage*hours;	
		}
		void print()
	{
		
			cout<<"first name is="<<first_name<<endl<<"last name is="<<last_name<<endl<<"ss number="<<ssn<<endl<<"salary ="<<salary<<endl;
	}
};
class Cemp:public Emp{
	int crate,grate;
	double salary;
	public:
		Cemp(string fn,string ln,int s,int c,int g):Emp(fn,ln,s)
		{
		crate=c;
		grate=g;	
		}
			double earning()
		{
			salary=( crate*(1+grate/100) );
		}
		void print()
	{
		
			cout<<"first name is="<<first_name<<endl<<"last name is="<<last_name<<endl<<"ss number="<<ssn<<endl<<"salary ="<<salary<<endl;
	}
};
class Bemp:Emp{
	
	double salary;
	public:
		Bemp(string fn,string ln,int ss,double b):Emp(fn,ln,ss)
		{
			salary=b;
		}
			double earning()
		{
			salary*=1.1;
		}
		void print()
	{
		
			cout<<"first name is="<<first_name<<endl<<"last name is="<<last_name<<endl<<"ss number="<<ssn<<endl<<"salary ="<<salary<<endl;
	}
};

int main()
{
	 Salaried_Employee s("Umair","Khan",132,43000);
	s.earning();
	s.print();
	Bemp b("Umer","Khan",342,7600);
	b.earning();
	b.print();
	Cemp c("Abu Bakar","Khan",124,532,106546);
	c.earning();
	c.print();
	hourly_Employee h("Umaira","Khan",215,4000,5);
	h.earning();
	h.print();
}
