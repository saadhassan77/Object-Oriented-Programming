#include<iostream>
using namespace std;
class Rectangle
{
	private:
		double length,width;
	public:		
		Rectangle()
		{
			length=1.0;
			width=1.0;
		}
		void setlength(double len)
		{
			if(len>0.0 && len<20.0) 
			{
				length=len;
			}
		}
		void setwidth(double wide)
		{
			if(wide>0.0 && wide<20.0)
			{
				width=wide;
			}
		}
		double getlength()
		{
			return length;
		}
		double getwidth()
		{
			return width;
		}
		double area()
		{
			return ( ( getlength() ) * ( getwidth() ) );
		}
		double perimeter()
		{
			return ( 2*( ( getlength() ) + ( getwidth() ) ) ) ;
		}
		void display()
		{
			cout<<endl<<"Length = "<<getlength();
			cout<<endl<<"Width = "<<getwidth();
			cout<<endl<<"Area = "<<area();
			cout<<endl<<"Perimeter = "<<perimeter();
		}
};
int main()
{
	Rectangle rect;
	double length,width;
	cout<<"enter length : ";
	cin>>length;
	cout<<"enter width : ";
	cin>>width;
	rect.setlength(length);
	rect.setwidth(width);
	rect.display();
}
