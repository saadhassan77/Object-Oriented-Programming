#include<iostream>
using namespace std;
int main()
{
	int a,b,c,d,e,f,g,h;
	printf("enter 3 digit number:\n");
	scanf("%d",&a);
	b=a%100;
	c=a/100;
	d=b/10;
	e=b%10;
	f=c*100;
	g=d*10;
	h=f + g + e;
	
	if (h==0)cout<<"zero";
	
	if (f==100 )cout<<"one hundred ";
	else if (f==200) cout<<"two hundred ";
	else if (f==300) cout<<"three hundred ";
	else if (f==400) cout<<"four hundred ";
	else if (f==500 )cout<<"five hundred ";
	else if (f==600 )cout<<"six hundred ";
	else if (f==700 )cout<<"seven hundred ";
	else if (f==800 )cout<<"eight hundred ";
	else if (f==900 )cout<<"nine hundred ";
	
if(g==10 )


{

if(e==0) cout<<"ten";
else if(e==1) cout<<"eleven";  
else if(e==2) cout<<"twelve"; 
  else if (e==3) cout<<"thirteen";
   else if (e==4) cout<<"forteen";
  else if (e==5) cout<<"fifteen";
  else if (e==6) cout<<"sixteen";
  else if (e==7) cout<<"seventeen"; 
  else if (e==8) cout<<"eighteen";
  else if (e==9) cout<<"nineteen";
}
else{
if(g==20)
 cout<<"twenty ";
	
	
	else if (g==30 ) cout<<"thirty ";
    else if (g==40) cout<<"fourty ";
	else if (g==50) cout<<"fifty ";
else if	(g==60 ) cout<<"sixty ";
	else if (g==70 ) cout<<"seventy ";
	else if (g==80 ) cout<<"eighty ";
	else if (g==90 ) cout<<"ninety ";
	
	
if(e==1 ) cout<<"one";
else if	 (e==2 ) cout<<"two";
	else if (e==3) cout<<"three";
    else if (e==4) cout<<"four";
	else if (e==5 ) cout<<"five";
    else if (e==6 ) cout<<"six";
    else if (e==7 ) cout<<"seven";
	else if (e==8 ) cout<<"eight";
	else if (e==9 ) cout<<"nine";

}
   return 0;
}


