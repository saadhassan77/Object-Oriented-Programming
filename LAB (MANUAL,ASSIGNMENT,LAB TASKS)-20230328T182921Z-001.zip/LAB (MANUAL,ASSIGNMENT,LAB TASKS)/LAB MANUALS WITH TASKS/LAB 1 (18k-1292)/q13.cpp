#include <iostream>
using namespace std;
void month_day(int month)
{
	switch(month)
	{
		case 1:
		case 3:
		case 5:
		case 7:
		case 8:
		case 10:
		case 12:	
			cout<<"number of days are: 31";
			break;
		case 2:
			cout<<"number of days are: 28/29";
			break;
		case 4:	
		case 6:
		case 9:
		case 11:	
			cout<<"number of days are: 30";
			break;	
		default:
		    cout<<"\nenter valid month number\n";
			break;								
	}
}
int main()
{
	int month;
	cout<<"enter the month number: ";
	cin>>month;
	month_day(month);
	return 0;
}

