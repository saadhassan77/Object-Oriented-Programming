#include<iostream>
using namespace std;

int main()
{
	int n,a,b,c,d,e,f,g,h,i,j,k,l;
   
    cout<<"\t\twithdraw only 100,50,20,10,5,2 and 1 notes\n\n";	
	cout<<"enter amount of money you want to withdraw: ";
	cin>>n;
	
	a=n/100;
	b=n%100;
	c=b/50;
	d=b%50;
	e=d/20;
	f=d%20;
	g=f/10;
	h=f%10;
	i=h/5;
	j=h%5;
	k=j/2;
	l=j%2;
	
	cout<<"\nnumber of notes you will get are:\n";
	cout<<a<<" note(s) of 100"<<endl;
	cout<<c<<" note(s) of 50"<<endl;
	cout<<e<<" note(s) of 20"<<endl;
	cout<<g<<" note(s) of 10"<<endl;
	cout<<i<<" note(s) of 5"<<endl;
	cout<<k<<" note(s) of 2"<<endl;
	cout<<l<<" note(s) of 1"<<endl;
	
	return 0;
}
