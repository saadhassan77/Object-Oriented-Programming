#include<iostream>
using namespace std;
int main()
{
	int num1,num2,num3,prod;
	cout<<"enter 1st number: ";
	cin>>num1;
	cout<<"\nenter 2nd number: ";
	cin>>num2;
	cout<<"\nenter 3rd number: ";
	cin>>num3;
	prod=num1*num2*num3;
	cout<<"\nproduct of number "<<num1<<" and number "<<num2<<" and number "<<num3<<" is "<<prod;
	return 0;
}
