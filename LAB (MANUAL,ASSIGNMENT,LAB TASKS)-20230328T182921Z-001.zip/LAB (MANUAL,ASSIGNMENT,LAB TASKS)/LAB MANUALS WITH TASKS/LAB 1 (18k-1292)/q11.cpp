#include<iostream>
using namespace std;
int main()
{
	int num;
	cout<<"enter a number: ";
	cin>>num;
	cout<<" "<<num;
	for(int i=0;i<10;i++)
	{
		num*=2;
		num+=2;
		cout<<"  "<<num;
	}
}
