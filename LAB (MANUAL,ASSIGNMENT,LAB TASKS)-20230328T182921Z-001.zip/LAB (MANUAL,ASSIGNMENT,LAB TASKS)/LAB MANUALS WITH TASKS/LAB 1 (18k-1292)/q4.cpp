#include<iostream>
using namespace std;
void swap_floats(float x,float y)
{
	float temp;
	temp=x;
	x=y;
	y=temp;
	cout<<"number 1 after swapping is "<<x<<endl;
	cout<<"number 2 after swapping is "<<y<<endl;
}
int main()
{
	float x;
	float y;
	cout<<"enter two numbers to be swapped:\n";
	cin>>x>>y;
	cout<<"number 1 before swapping is "<<x<<endl;
	cout<<"number 2 before swapping is "<<y<<endl;
	swap_floats(x,y);
	return 0;
}
