#include<iostream>
#include<stdio.h>

using namespace std;
class Product{
	protected:
		string barcode,name;
	public:
		Product(string code=" ", string name=" "):barcode(code),name(name){
		}
		void setname(string name){
			this->name=name;
		}
		string getname(){
			return name; 
		} 
		void setcode(string code){
			barcode=code;
		}
		string getcode(){
			return barcode;
		} 	
		void scanner(){
			fflush(stdin);
			cout<<endl<<"Enter code : ";
			getline(cin,barcode);
			fflush(stdin);
			cout<<"Enter name : ";
			getline(cin,name);
		}
		void printer(){
			cout<<endl<<"Barcode : "<<barcode<<endl<<"Name : "<<name<<endl;
		}
		void display(){
			cout<<endl<<"Barcode : "<<getcode()<<endl<<"Name : "<<getname()<<endl;
		}
};
class PrePackedFood:public Product{
	protected:
		double unitprice;
	public:
		PrePackedFood(string name=" ", string code=" ", double u_p=0.0):Product(code,name),unitprice(u_p){
		}
		void setu_p(double u_p){
			unitprice=u_p;
		}
		double getu_p(){
			return unitprice;
		}
		void scanner(){
			cout<<endl;
			Product::scanner();
			cout<<"Enter unit price : ";
			cin>>unitprice;
		}
		void printer(){
			Product::printer();
			cout<<"Unit Price : "<<unitprice<<endl;
		}
		void display(){
			Product::display();
			cout<<"Unit Price : "<<getu_p()<<endl;
		}
};
class FreshFood:public Product{
	protected:
		double weight,priceperkilo;
	public:
		FreshFood(string name=" ", string code=" ", double w=0.0, double ppk=0.0):Product(code,name),weight(w),priceperkilo(ppk){
		}
		void setdetails(double w, double ppk){
			weight=w;
			priceperkilo=ppk;
		}
		double getw(){
			return weight;
		}
		double getppk(){
			return priceperkilo;
		}
		void scanner(){
			Product::scanner();
			cout<<"Enter weight : ";
			cin>>weight;
			cout<<"Enter price per kilo : ";
			cin>>priceperkilo;
		}
		void printer(){
			Product::printer();
			cout<<"Weight : "<<weight<<endl<<"Price Per Kilo : "<<priceperkilo<<endl;
		}
		void display(){
			Product::display();
			cout<<"Weight : "<<getw()<<endl<<"Price Per Kilo : "<<getppk()<<endl;
		}
};
int main(){
	cout<<"Product"<<endl;
	Product pro(),pro1,pro2;
	pro1.scanner();
	pro1.printer();
	pro2.setcode("Q-789");
	pro2.setname("Flour");
	pro2.display();
	
	cout<<endl<<"PrePackedFood"<<endl;
	PrePackedFood p(),p1,p2;
	p1.scanner();
	p1.printer();
	p2.Product::setcode("A-798");
	p2.Product::setname("Brush");
	p2.setu_p(3.26);
	p2.display();

	cout<<endl<<"Fresh Food"<<endl;
	FreshFood f(),f1,f2;	
	f1.scanner();
	f1.printer();
	f2.Product::setcode("A-798");
	f2.Product::setname("Paint");
	f2.setdetails(2.3,10.5);
	f2.display();

}

