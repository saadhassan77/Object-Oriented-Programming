#include<iostream>
using namespace std;
class Person{ 
	private: 
		int age; 
	protected: 
		string name; 
	public:
		Person(string name, int x){
			this->name=name;
			age=x;
		}
		string getname()const{
			return name;
		}
		int getage()const{
			return age;
		}	
}; 
class Employee{ 
	private:  
		int empId; 
	protected:
		double salary; 
	public:
		Employee(double sal , int ID){
			empId=ID;
			salary=sal;
		}
		int getID()const{
			return empId;
		}
		double getsalary()const{
			return salary;
		}	
}; 
class Manager:public Person, public Employee{ 
	protected: 
		string type;
	public:
		Manager(string type, string name, int empID, int age, double salary ):Person(name,age),Employee(salary,empID){
			this->type=type;
		} 
		string gettype()const{
			return type;
		}
};
class ITManager:public Manager{ 
	private: 
		int noOfPersons; 
	public:
		ITManager(int n,string type, string name, int empID, int age, double salary ):Manager(type,name,empID,age,salary){
			noOfPersons=n;
		}
		int getnoOfPersons()const{
			return noOfPersons;
		} 
		void Display()const{
			cout<<"Name : "<<getname()<<endl<<"Age : "<<getage()<<endl<<"ID : "<<getID()<<endl<<"Salary : "<<getsalary()<<endl
			<<"Type : "<<gettype()<<endl<<"Number Of Persons : "<<getnoOfPersons()<<endl;
		}; 
}; 	 
int main(){
	ITManager obj(6,"programmer","Muteeb",12344,24,1600.56);
	obj.Display();
}
