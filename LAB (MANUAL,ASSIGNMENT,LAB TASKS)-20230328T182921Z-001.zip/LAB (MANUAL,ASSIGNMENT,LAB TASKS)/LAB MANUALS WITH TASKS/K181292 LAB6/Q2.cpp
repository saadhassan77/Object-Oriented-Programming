#include<iostream>
using namespace std;
class Employee{
	private:
		int ID;
		string last_name;
	public:
		Employee(){
			ID=0;
			last_name='NULL';
		}
		Employee(string name,int id){
			last_name=name;
			ID=id;
		}
		string getname(){
			return last_name;
		}
		int getid(){
			return ID;
		}
};
class Manager:public Employee{
	private:
		string title;
		double dues;
	public:
		Manager():Employee(){
			title='NULL';
			dues=0.0;
		}
		Manager(string t, double d, string name, int id):Employee(name,id){
			title=t;
			dues=d;
		}
		string gettitle(){
			return title;
		}
		double getdues(){
			return dues;
		}
		void show(){
			cout<<"\nManager\n"<<"Name : "<<getname()<<endl<<"ID : "<<getid()<<endl<<"Title : "<<gettitle()<<endl<<"Club Dues : "<<getdues()<<endl;
		}	
};
class Scientist:public Employee{
	private:
		string title;
		int noOfpublications;
	public:
		Scientist():Employee(){
			title='NULL';
			noOfpublications=0;
		}
		Scientist(string t, int num , string name, int id):Employee(name,id){
			title=t;
			noOfpublications=num;
		}
		string gettitle(){
			return title;
		}		
		int getpublications(){
			return noOfpublications;
		}
		void show(){
			cout<<"\nScientist\n"<<"Name : "<<getname()<<endl<<"ID : "<<getid()<<endl<<"Title : "<<gettitle()<<endl<<"Number Of Publications : "
			<<getpublications()<<endl;
		}	
};
class Laborer:public Employee{
	private:
		string title;
	public:
		Laborer():Employee(){
			title='NULL';
		}
		Laborer(string t, string name, int id):Employee(name,id){
			title=t;
		}
		string gettitle(){
			return title;
		}
		void show(){
			cout<<"\nLaborer\n"<<"Name : "<<getname()<<endl<<"ID : "<<getid()<<endl<<"Title : "<<gettitle()<<endl;
		}
};
int main(){
	Manager m("G.M",29993.26,"Muteeb ",654);
	m.show();
	Scientist s("Lab.Researscher",10,"Javed",456);
	s.show();
	Laborer l("Head","Chaudry",789);
	l.show();
}
