#include <iostream>
#include <fstream>

  
using namespace std;

class person{
	string name;
	int age;
	public :
		person(){
		}
		
		person(string n,int a)
		{
			name=n;
			age=a;
			
		}
		
		getdata()
		{
			cout<<"\nname : "<<name;
			cout<<"\nage : "<<age;
			
		}
	
};

int main()
{


	fstream file;
	file.open("person.txt",ios::out|ios::binary);
     person person1("Umair",19);
     file.write((char*)&person1,sizeof(person1));
     file.close();
      file.open("person.txt",ios::in|ios::binary);
    file.read((char*)&person1,sizeof(person1));
    person1.getdata();
    return 0;
    
}
