#include <iostream>
#include <fstream>

using namespace std;

class participant
{
public:	
   string name;
   int id;
   int score;	
	input()
	{
    	fstream myfile;
		myfile.open("particpant.txt",ios::out|ios::app);
    	
		cout<<"\nenter name, id and score ";
		cin>>name;
		cin>>id;
		cin>>score;
				myfile<<name;
		myfile<<id;
		myfile<<score<<endl;
		myfile.close();
		
	}
	
	friend output(int ,participant,int);
	friend max(participant,int n);
	

};

output(int m, const participant p[],int n)
{
	int i;
	for(i=0;i<n;i++)
	{
		if (p[i].id==m)
		{
			cout<<"\ninformation of respective id member is \nName : "<<p[i].name<<"\nscore : "<<p[i].score;
		}
	}
}
max(participant p[],int n)
{
	int i,temp=0;
	for(i=0;i<n;i++)
	{
		if(p[i].score>temp)
		temp=p[i].score;
	}
	cout<<"\n\nmaximun score is : "<<temp;
}

int main()
{
	int n;
	cout<<"How many participants data you want to enter ? ";
	cin>>n;
	participant p[n];
	int i;
	for(i=0;i<n;i++)
{
	cout<<i+1<<" participant information ";
	p[i].input();
}
int id;
cout<<"enter id to match : ";
cin>>id;
output(id,p,n);
max(p,n);

}
