#include<iostream>
using namespace std;
class BankAccount{
	private:
		string Name;
		const string accountnumber  ; 
		string account_type;
		static int balance;		
		static float rate;
	public:
		float amount,amount1;
		BankAccount(){
			rate=0;
		}
		BankAccount(string Name,string account_type,int balance,string num):accountnumber(num){
			this->Name=Name;
			this->account_type=account_type;
			this->balance=balance;
		}
		float depositamount(){
			return balance+amount;
		}
		float withdraw(){;
			if(amount1>balance){
				cout<<"Invalid Amount Entered!"<<endl;
				return 0;
			}
			else{
				return balance-amount1;
			}			
		}
		void display(){
			cout<<endl<<"Name : "<<Name<<endl;
			cout<<"Account number : "<<accountnumber<<endl;
			cout<<"Account Type : "<<account_type<<endl;
			cout<<"Balance : "<<balance<<endl;
	
			cout<<endl<<"Current Amount : "<<balance;
			cout<<endl<<"Deposited Amount : "<<depositamount()<<endl;
			cout<<"Withdrawed Amount : "<<withdraw()<<endl; 
		}
		static void display_rateOfInterest(){
			rate=(300000*12.5*22)/100;
			cout<<endl<<"Rate : "<<rate;
		}
};

int BankAccount::balance;
float BankAccount::rate;

int main(){
		
	string Name;
	string account_type;
	int balance;
	string accountnumber; 		

	cout<<"Enter Name : ";
	getline(cin,Name);
	cout<<"Enter Account Type (Current/Saving) : ";
	getline(cin,account_type);
	cout<<"Enter Balance : ";
	cin>>balance;
	
	BankAccount acc2(Name,account_type,balance,"6548646");
	cout<<"Enter Amount You Want To Deposit : "; 
	cin>>acc2.amount;
	acc2.depositamount();
	cout<<"Enter Amount You Want To withdraw : "; 
	cin>>acc2.amount1;
	acc2.withdraw();
	
	acc2.display();

	BankAccount::display_rateOfInterest();
}
