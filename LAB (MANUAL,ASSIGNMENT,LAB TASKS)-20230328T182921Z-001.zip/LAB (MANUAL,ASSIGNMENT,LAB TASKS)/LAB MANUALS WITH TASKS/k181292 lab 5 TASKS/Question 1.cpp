#include<iostream> 
using namespace std;
 
class Employee
{
	private:
		const int EmployeeID;
		char *EmployeeName;
		
	public:
		Employee(int EMP_ID):EmployeeID(EMP_ID){}
		void accessors(char* j)
		{
			EmployeeName=j;
		}
		void print()
		{
			cout<<"Employee Name:- "<<EmployeeName<<"\t"<<"ID#:"<<EmployeeID<<endl;
		}
		
		
};
int main()
{
	Employee e1(123);
	e1.accessors("Muteeb");
	e1.print();
	Employee e2(456);
	e2.accessors("Hassam");
	e2.print();
	Employee e3(789);
	e3.accessors("Zuhaid");
	e3.print();
}
