#include<iostream>
#include<iomanip>
#include<string>
using namespace std;

template<typename T , typename U>
T mul(T x , U y)
{
	return (x*y);
}
template<typename T , typename U , typename Z>
T mul(T x , U y , Z z)
{
	return (x*y*z);
}
main()
{
	cout << setprecision(3) << "Result of two is " << mul(2.5 , 11) << endl;
	cout << setprecision(3) << "Result of three is " << mul(3 , 4.3 , 6.3);
}
