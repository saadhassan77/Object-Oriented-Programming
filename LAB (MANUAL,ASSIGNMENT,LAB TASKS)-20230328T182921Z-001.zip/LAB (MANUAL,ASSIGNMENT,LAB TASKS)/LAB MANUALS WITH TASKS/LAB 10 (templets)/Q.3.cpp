#include<iostream>
#include<iomanip>
#include<cstring>
using namespace std;

template <typename T , typename U>  
class Addition{
	public:
		T t1;
		U t2;
		Addition() {
		}
		Addition(T x , U y)  {
			t1 = x;
			t2  = y;
		}
		void add()
		{
			cout << (t1+t2) << endl;
		}
		void add(char* str1,const char* str2)
		{
			cout << strcat(str1,str2) << endl;
		}
};
int main()
{
	Addition <int , float> c1(10 , 0.3);       
	c1.add();

	Addition <string , string> c2("Now" , "Then");       
	c2.add();

	Addition<const char*, const char*>c3;
	char str1[4] = "Now";
	char str2[5] = "Then";
	c3.add(str1,str2);
}


