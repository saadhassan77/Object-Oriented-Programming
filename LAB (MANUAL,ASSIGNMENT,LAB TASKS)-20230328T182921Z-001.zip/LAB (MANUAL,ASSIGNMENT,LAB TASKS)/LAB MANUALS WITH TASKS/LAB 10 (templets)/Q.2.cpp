#include<iostream>
using namespace std;

template <typename T>
void bubblesort(T array[], int size)
{
	for (int i=0;i<size-1;i++)
	{
		for (int j=0;j<size-1;j++)
		{
			if (array[j]>array[j+1])
			{
				swap (array[j],array[j+1]);
			}
		}
	}
}

int main()
{
	int array[7] = {123,456,11,22,33,54,8};
	bubblesort(array,7);
	cout << "Sorted Int\n";
	for (int i=0;i<7;i++)
	{
		cout << array[i] << " ";
	}

	float array2[5] = {1.0,2.0,3.0,4.2,9.3};
	bubblesort(array2, 5);
	cout << endl << "Sorted Float" << endl;
	for (int i=0;i<5;i++)
	{
		cout <<array2[i] << " ";
	}
}
